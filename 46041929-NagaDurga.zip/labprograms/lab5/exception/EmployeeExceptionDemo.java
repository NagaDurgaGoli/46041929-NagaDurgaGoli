package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends Exception{
	
}

public class EmployeeExceptionDemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetr your salary");
		int salary=sc.nextInt();
		final  int min=30000;
		try {
			if (salary < min)
				throw new EmployeeException();
				
		}
		catch(EmployeeException e) {
			System.out.println("salary limit is low");
		}
	}

}
