package lab5;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
class FullnameException extends Exception{
	FullnameException(){
			super();
	}
}
public class FullnameValidation {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your first name");
		String firstName=sc.next();
		System.out.println("Enter your last name");
		String lastName=sc.next();
		try {
			if(firstName==null && lastName==null) 
				throw new FullnameException();
		}
		catch(FullnameException e) {
			System.out.println("Your name should not be blank");
			
		}
		String s=firstName+lastName;
		Pattern p=Pattern.compile("[a-zA-Z] {20}");
		Matcher matcher=p.matcher(s);
		boolean b=matcher.matches();
		if(b)
			System.out.println(s);
		else
			System.out.println("Invalid name");
			
		
	}


}
