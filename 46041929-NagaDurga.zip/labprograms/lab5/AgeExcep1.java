package lab5;
import java.util.Scanner;
class AgeException extends Exception{
	public AgeException(String msg) {
		System.out.println(msg);
	}
}


public class AgeExcep1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Age");
		int age=sc.nextInt();
		try {
			if(age<15)
				throw new AgeException(" you should be above 15");
			else
				System.out.println("Valid age");
		}
		catch(AgeException e) {
			System.out.println(e);
		}

	}

}
