import java.util.Arrays;

public class GetSorted {
  static void getSorted(int[] array) {
	  int n=array.length;
	  int reverse[]=new int[n];
	  int j=n;
	  for(int i=0;i<n;i++) {
		  reverse[j-1]=array[i];
		  j=j-1;
	  }
	  System.out.println("After Reversing the Array");
	  for(int k=0;k<n;k++) {
		  System.out.println(reverse[k]);
	  }
	  Arrays.sort(array);
	  System.out.println("After Sorting the Array");
	  for(int p=0;p<array.length;p++) {
		  System.out.println(array[p]);
	  }
}
public static void main(String[] args) {
	int[] arr= {20,10,50,5,70,90};
	getSorted(arr);
}
}

