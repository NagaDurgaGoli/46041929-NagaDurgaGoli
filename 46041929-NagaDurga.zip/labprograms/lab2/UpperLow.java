import java.util.Arrays;


public class UpperLow {
	void sortStrings(String[] arr) {
		Arrays.sort(arr);
		int s=arr.length;
		for(int i=0;i<s/2;i++)
		{
			 arr[i]=((arr[i]).toLowerCase());
		}
		for(int i=s/2;i<s;i++)
		{
			arr[i]=((arr[i]).toUpperCase());
		}
		for(String element:arr) {
			System.out.println(element);
		}
			
	}
	public static void main(String[] args){
		String str[]= {"Jhon","Joe","Joi","Jio"};
		UpperLow s2=new UpperLow();
		s2.sortStrings(str);
	}
}
