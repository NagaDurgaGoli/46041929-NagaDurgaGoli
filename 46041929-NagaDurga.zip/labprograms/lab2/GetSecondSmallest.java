

public class GetSecondSmallest {
	
	 static int getSecondSmallest(int arr[],int n) {
		 int temp;
		 for(int i=0;i<n;i++) 
		 {
			 for(int j=i+1;j<n;j++) 
			 {
				 if(arr[i]>arr[j])
				 {
					 temp=arr[i];
					 arr[i]=arr[j];
					 arr[j]=temp;
				 } 
			 }
		 }
		 return arr[1];
	 }
	 public static void main(String args[]) {
		 int arr[]= {12,56,78,90,10,56,13};
		 System.out.println("The second smallest element is "+getSecondSmallest(arr,7));
	 }
	}
