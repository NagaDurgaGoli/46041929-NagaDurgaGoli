import java.util.Scanner;
public class ModifyNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sum=0;
		int h=num%10;
		while(num!=0)
		{
			int a=num%10;
			sum=sum*10+a;
			num=num/10;
			
		}
	
		
		while(sum!=0)
		{
			int k=sum%10;
			sum=sum/10;
			int l=sum%10;
			int result=k-l;
			System.out.print(result);
		}
	}

}
