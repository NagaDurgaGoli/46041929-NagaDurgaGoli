import java.util.Scanner;
public class GetString {

	public static void main(String[] args ) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String str=sc.next();
		
		int k=str.length();
		for(int i=0;i<k;i++)
			
		{
	         char j=str.charAt(i);
		
			if(j=='a'||j=='e'||j=='i'||j=='o'||j=='u') 
			{
				
				System.out.print(j);
		   }
			else 
			{
				char ch=  str.charAt(i);
				ch++;
				System.out.print(ch);
			
		    }
		}
		
		
	}

}
