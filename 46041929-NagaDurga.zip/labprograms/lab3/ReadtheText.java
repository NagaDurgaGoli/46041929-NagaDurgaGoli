public class ReadtheText {

	public static void main(String[] args) {
		String str="hello hai jhon";
		int words=0,character=0,line=0;
		for(int i=0;i<str.length();i++)
		{
		if(str.charAt(i)==' ')
		{
			words++;
		}
		if(str.charAt(i)=='\n')
		{
			line++;
		}
        character++;
	}

		System.out.println("characters ="+ character+" words "+words+" Lines "+line);
}
}