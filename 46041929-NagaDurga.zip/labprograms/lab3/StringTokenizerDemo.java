import java.util.*;
 
class StringTokenizerDemo {
    public static void main(String args[]) {
        int n;
        int sum = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter integers:");
        String s = sc.nextLine();
        StringTokenizer stringtoken = new StringTokenizer(s, " ");
        while (stringtoken.hasMoreTokens()) {
            String temp = stringtoken.nextToken();
            n = Integer.parseInt(temp);
            System.out.println(n);
            sum = sum + n;
        }
        System.out.println("sum of the integers is: " + sum);
        sc.close();
    }
}
