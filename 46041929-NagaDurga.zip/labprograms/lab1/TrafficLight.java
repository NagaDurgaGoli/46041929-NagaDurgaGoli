import java.util.Scanner;
public class TrafficLight {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choiice");
		String light=sc.nextLine();
		sc.close();
		if(light.equals("red")) {
			System.out.println("stop");
		}
		else if(light.equals("yellow")) {
			System.out.println("ready");
		}
		else {
			System.out.println("go");
		}
		
	}

}
