
public class SumOfCubes {
	static int sum=0;
	static int sumOfCubes(int n) {
		while(n>0) {
			int num1=n%10;
			sum=sum+(num1*num1*num1);
			n=n/10;
		}
		return sum;
	}
	public static void main(String[] args){
		System.out.println(sumOfCubes(151));
		
	}
}
