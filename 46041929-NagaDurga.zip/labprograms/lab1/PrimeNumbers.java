
public class PrimeNumbers {
	static String  primenumber="";
     static String primeNumbers(int n) {
    	 for(int i=1;i<=n;i++) {
    		 int count=0;
    		 for(int j=i;j>=1;j--) {
    			 if(i%j==0) {
    				  count=count+1;
    			 }
    		 }
    			 if(count==2)
    			 {
    				 primenumber=primenumber+i+" ";
    			 }
    		 
    	 }
    	 return primenumber;
     }
     public static void main(String[] args) {
		System.out.println(primeNumbers(10));
	}
}
