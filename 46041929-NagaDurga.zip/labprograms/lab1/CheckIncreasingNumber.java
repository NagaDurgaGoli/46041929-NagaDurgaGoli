
public class CheckIncreasingNumber {
	int number=0;
	static int digit=0;
	static boolean flag=false;
	static boolean checkNumber(int n) {
		while(n>0)
		{
			digit=n%10;
			n=n/10;
			if(digit<n%10) {
				flag = true;
				break;
			}	
		}	
		return flag;
	} 
	public static void main(String[] args) {
		checkNumber(1234821);
		if(flag) {
			System.out.println("It is not an increasing number ");
		}
		else {
			System.out.println("It is a increasing number");
		}
	}
	
}
