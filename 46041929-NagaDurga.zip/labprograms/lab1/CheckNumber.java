
public class CheckNumber {
	static int number;
	 static boolean value;
	static boolean checkNumber(int n){
		for(int i=0;i<=n/2;i++) {
			number=n%2;	
		}
		if(number==0) {
			value=true;
		}
		else {
			value=false;
		}
		return value;
	}
	public static void main(String[] args) {
		System.out.println(checkNumber(8));
	}

}
