package com.cg.spring.rest.lab2;

import org.springframework.data.repository.CrudRepository;

public interface TraineJpaRepository extends CrudRepository<Trainee, Integer> {
}