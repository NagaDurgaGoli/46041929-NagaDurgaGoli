package com.gp.spring.labassignment1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        System.out.println( "Start" );
        ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
        Employee employee = context.getBean("employee", Employee.class);
       System.out.println(employee.toString());
       SBU sbu = context.getBean("sbu", SBU.class);
       System.out.println(sbu.toString());
        
        
        /*ApplicationContext context=new AnnotationConfigApplicationContext(Config.class);

    	Employee emp1=context.getBean("emp1",Employee.class);
    	Employee emp2=context.getBean("emp2",Employee.class);
    	Employee emp3=context.getBean("emp3",Employee.class);
    	Employee emp4=context.getBean("emp4",Employee.class);
    	Employee emp5=context.getBean("emp5",Employee.class);
    	
    	System.out.println("Employee ID: ");
    	Scanner sc=new Scanner(System.in);
    	int val=sc.nextInt();
    	
    	List<Employee> empList=new ArrayList<Employee>();
    	empList.add(emp1);
    	empList.add(emp2);
    	empList.add(emp3);
    	empList.add(emp4);
    	empList.add(emp5);
    	 
    	for(Employee e: empList)
    	{
    		if(e.getEmployeeId()==val)
    			System.out.println(e);
    	}
    	
    	sc.close();*/
    	 
       
    }
}
